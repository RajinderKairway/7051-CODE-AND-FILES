
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class RetrieveDoctor
 */
@WebServlet("/ShowOrder")
public class ShowOrder extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ShowOrder() {
		super();
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		try {
			Connection c = GetConnection.getConnection();

			// for Non_Veg Pizza
			String sql_nv = "select * from user u, non_veg nv where u.email = nv.uid";
			PreparedStatement ps_nv = c.prepareStatement(sql_nv);
			//ps_nv.setString(1, new SimpleDateFormat("yyyy-MM-dd").format(new Date()));
			ps_nv.addBatch();
			ResultSet r_nv = ps_nv.executeQuery();
			// ResultSetMetaData rms = r.getMetaData();
			ps_nv.clearBatch();
			if (r_nv.next()) {
				out.println("<table>");
				out.println("<caption>Today's Non-Veg Pizza Order</caption>");
				out.println("<td>");
				out.println("<th>SIZE</th>");
				out.println("<th>TOPPINGS</th>");
				out.println("<th>CRUST</th>");
				out.println("<th>REMARKS</th>");
				out.println("</td>");
				while (r_nv.next()) {
					out.println("<tr>");
					out.println("<td></td>");
					out.println("<td>" + r_nv.getString("size") + "</td>");
					out.println("<td>" + r_nv.getString("toppings") + "</td>");
					out.println("<td>" + r_nv.getString("crust") + "</td>");
					out.println("<td>" + r_nv.getString("remarks") + "</td>");
					out.println("<td>" + r_nv.getString("uid") + "</td>");
					out.println("<td>" + r_nv.getString("name") + "</td>");
					out.println("<td>" + r_nv.getString("orderdate") + "</td>");
					out.println("</tr>");
				}
				out.println("</table>");
			}

			// for Veg Pizza
			String sql_v = "select * from user u, veg v where u.email = v.uid ";
			PreparedStatement ps_v = c.prepareStatement(sql_v);
			//ps_v.setString(1, new SimpleDateFormat("yyyy-MM-dd").format(new Date()));
			ps_v.addBatch();
			ResultSet r_v = ps_v.executeQuery();
			// ResultSetMetaData rms = r.getMetaData();
			ps_v.clearBatch();
			if (r_v.next()) {
				out.println("<table>");
				out.println("<caption>Today's Veg Pizza Order</caption>");
				out.println("<td>");
				out.println("<th>SIZE</th>");
				out.println("<th>TOPPINGS</th>");
				out.println("<th>CRUST</th>");
				out.println("<th>REMARKS</th>");
				out.println("</td>");
				while (r_v.next()) {
					out.println("<tr>");
					out.println("<td></td>");
					out.println("<td>" + r_v.getString("size") + "</td>");
					out.println("<td>" + r_v.getString("toppings") + "</td>");
					out.println("<td>" + r_v.getString("crust") + "</td>");
					out.println("<td>" + r_v.getString("remarks") + "</td>");
					out.println("<td>" + r_v.getString("uid") + "</td>");
					out.println("<td>" + r_v.getString("name") + "</td>");
					out.println("<td>" + r_v.getString("orderdate") + "</td>");
					out.println("</tr>");
				}
				out.println("</table>");
			}

			// for Fruit Juice
			String sql_fj = "select * from user u, fruit_juice fj where u.email = fj.uid ";
			PreparedStatement ps_fj = c.prepareStatement(sql_fj);
			//ps_fj.setString(1, new SimpleDateFormat("yyyy-MM-dd").format(new Date()));
			ps_fj.addBatch();
			ResultSet r_fj = ps_fj.executeQuery();
			// ResultSetMetaData rms = r.getMetaData();
			ps_fj.clearBatch();
			if (r_fj.next()) {
				out.println("<table>");
				out.println("<caption>Today's Fruit Juice Order</caption>");
				out.println("<td>");
				out.println("<th>SIZE</th>");
				out.println("<th>TOPPINGS</th>");
				out.println("<th>FRUIT TYPE</th>");
				out.println("<th>REMARKS</th>");
				out.println("</td>");
				while (r_fj.next()) {
					out.println("<tr>");
					out.println("<td></td>");
					out.println("<td>" + r_fj.getString("size") + "</td>");
					out.println("<td>" + r_fj.getString("toppings") + "</td>");
					out.println("<td>" + r_fj.getString("crust") + "</td>");
					out.println("<td>" + r_fj.getString("remarks") + "</td>");
					out.println("<td>" + r_fj.getString("uid") + "</td>");
					out.println("<td>" + r_fj.getString("name") + "</td>");
					out.println("<td>" + r_fj.getString("orderdate") + "</td>");
					out.println("</tr>");
				}
				out.println("</table>");
			}

			// for Ice Cream
			String sql_ic = "select * from user u, ice_cream ic where u.email = ic.uid where ic.orderdate =?";
			PreparedStatement ps_ic = c.prepareStatement(sql_ic);
			ps_ic.setString(1, new SimpleDateFormat("yyyy-MM-dd").format(new Date()));
			ps_ic.addBatch();
			ResultSet r_ic = ps_ic.executeQuery();
			// ResultSetMetaData rms = r.getMetaData();
			ps_ic.clearBatch();
			if (r_ic.next()) {
				out.println("<table>");
				out.println("<caption>Today's Ice Cream Order</caption>");
				out.println("<td>");
				out.println("<th>SIZE</th>");
				out.println("<th>TOPPINGS</th>");
				out.println("<th>FLAVOUR</th>");
				out.println("<th>REMARKS</th>");
				out.println("</td>");
				while (r_ic.next()) {
					out.println("<tr>");
					out.println("<td></td>");
					out.println("<td>" + r_ic.getString("size") + "</td>");
					out.println("<td>" + r_ic.getString("toppings") + "</td>");
					out.println("<td>" + r_ic.getString("crust") + "</td>");
					out.println("<td>" + r_ic.getString("remarks") + "</td>");
					out.println("<td>" + r_ic.getString("uid") + "</td>");
					out.println("<td>" + r_ic.getString("name") + "</td>");
					out.println("<td>" + r_ic.getString("orderdate") + "</td>");
					out.println("</tr>");
				}
				out.println("</table>");
			}

			out.println("<table><caption>Address: " + r_ic.getString("address") + "</caption></table>");

		} catch (SQLException e) {
			response.setContentType("text/html");
			out.println("<br><br><br><h1 align=center><font color=\"red\">TRY AGAIN<br></font></h1>");
			e.printStackTrace();
		}

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
