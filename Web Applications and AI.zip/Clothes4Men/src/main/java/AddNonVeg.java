import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet Adds new doctor in doctor Table<br> CreateDoctor
 */
@WebServlet("/AddNonVeg")
public class AddNonVeg extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddNonVeg() {
        super();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
		PrintWriter out = response.getWriter();
		try {
			HttpSession sess = request.getSession();
			Connection c = GetConnection.getConnection();
			String  size = request.getParameter("size");
			String  toppings = request.getParameter("toppings");
			String  crust = request.getParameter("crust");
			String  remarks = request.getParameter("remarks");
			String orderdate = new SimpleDateFormat("yyyy-MM-dd").format(new Date());			
			String sql = "insert into non_veg(size,toppings,crust,remarks,orderdate,uid) values(?,?,?,?,?,?)";
	
			PreparedStatement ps = c.prepareStatement(sql);
			ps.setString(1, size);
			ps.setString(2, toppings);
			ps.setString(3, crust);
			ps.setString(4, remarks);
			ps.setString(5, orderdate);		
			ps.setString(6, (String) sess.getAttribute("email"));
			ps.addBatch();
			
			int successCount = 0;
			successCount += ps.executeBatch()[0];
			ps.clearBatch();
			
			if(successCount == 1) {
				response.setContentType("text/html");  
				out.println("<br><br><br><h1 align=center><font color=\"green\">SUCCESSFUL<br></font></h1><script type=\"text/javascript\">");  
//				out.println("redirectURL = \"welcome.html\";setTimeout(\"location.href = redirectURL;\",\"5000\");");  
				out.println("</script>");
			}
			else {
				response.setContentType("text/html");  
				out.println("<br><br><br><h1 align=center><font color=\"red\">THERE IS SOME PROBLEM<br></font></h1><script type=\"text/javascript\">");  
//				out.println("redirectURL = \"welcome.html\";setTimeout(\"location.href = redirectURL;\",\"5000\");");  
				out.println("</script>");
			}
		} catch (SQLException e) { 
			e.printStackTrace();
		}
	}

}
