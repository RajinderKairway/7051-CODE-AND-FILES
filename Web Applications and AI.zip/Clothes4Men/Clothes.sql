CREATE SCHEMA `food` ;

CREATE TABLE `food`.`user` (
  `email` VARCHAR(45) NOT NULL,
  `name` VARCHAR(45) NULL,
  `phone` VARCHAR(45) NULL,
  `joindate` VARCHAR(45) NULL,
  `password` VARCHAR(45) NULL,
  `address` VARCHAR(45) NULL,
  PRIMARY KEY (`email`));
  
  CREATE TABLE `food`.`non_veg` (
  `size` VARCHAR(45) NULL,
  `toppings` VARCHAR(45) NULL,
  `crust` VARCHAR(45) NULL,
  `remarks` VARCHAR(45) NULL,
  `orderdate` VARCHAR(45) NOT NULL,
  `uid` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`orderdate`, `uid`));

CREATE TABLE `food`.`veg` (
  `size` INT NOT NULL,
  `toppings` VARCHAR(45) NULL,
  `crust` VARCHAR(45) NULL,
  `remarks` VARCHAR(45) NULL,
  `orderdate` VARCHAR(45) NOT NULL,
  `uid` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`size`, `orderdate`, `uid`));
  
  CREATE TABLE `food`.`fruit_juice` (
  `size` INT NOT NULL,
  `toppings` VARCHAR(45) NULL,
  `crust` VARCHAR(45) NULL,
  `remarks` VARCHAR(45) NULL,
  `orderdate` VARCHAR(45) NOT NULL,
  `uid` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`size`, `orderdate`, `uid`));
  
   CREATE TABLE `food`.`ice_cream` (
  `size`VARCHAR(45) NULL,
  `toppings` VARCHAR(45) NULL,
  `crust` VARCHAR(45) NULL,
  `remarks` VARCHAR(45) NULL,
  `orderdate` VARCHAR(45) NOT NULL,
  `uid` VARCHAR(45) NOT NULL,
  PRIMARY KEY ( `orderdate`, `uid`));
  
